package co.edu.unipiloto;

import java.util.ArrayList;
import java.util.List;

public class BeerExpert {

    List<String> getBrands(String color){
        List<String> tipoC = new ArrayList<>();
        if(color.equals("AMBER")){
            tipoC.add("Jack Amber");
            tipoC.add("Red Moose");
        }

        else{
            tipoC.add("Jail Pale Ale");
            tipoC.add("Gout Stout");         }
            return tipoC;
    }
}
